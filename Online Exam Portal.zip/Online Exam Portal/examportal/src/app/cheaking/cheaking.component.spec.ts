import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheakingComponent } from './cheaking.component';

describe('CheakingComponent', () => {
  let component: CheakingComponent;
  let fixture: ComponentFixture<CheakingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CheakingComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CheakingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
