import { Component } from '@angular/core';
import { User, UserService } from '../user.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-user',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent    {
    message:string="";
  user:User=new User('','',0,'');
 

  

  constructor(private userservice:UserService)
  {

  }
  
  
  saveToDB()
  {

    console.log(this.user.username);

    this.userservice.saveToDB(this.user).subscribe();

  }
}
