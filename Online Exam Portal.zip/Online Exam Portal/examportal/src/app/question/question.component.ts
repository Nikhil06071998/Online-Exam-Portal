import { Component, OnInit } from '@angular/core';
import { Answer, Question, QuestionService } from '../question.service';
import { CommonModule } from '@angular/common';
import { FormsModule, NgModel } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-question',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './question.component.html',
  styleUrl: './question.component.css'
})
export class QuestionComponent implements OnInit

{
  subject:any="";
  username:any="";
  question:Question=new Question(0,'','','','','','','');
  answer:Answer=new Answer(0,'','','');
  submittedAnswer: string ="";
  selected=false;
  allAnswers:Answer[]=[];
  remainingTime:any="121";
  durationMessage:string="";
  x:any="";
  maxtime:any="";
  allqnos:number[]=[];


  
  constructor(private questionService:QuestionService,private router:Router)
  {
    this.subject=sessionStorage.getItem("subject");
    this.username=sessionStorage.getItem("username");
  }
  ngOnInit(): void 
  {
    
    this.questionService.getFirstQuestion(this.subject).subscribe(question=>this.question=question);
    this.questionService.getAllQuestions(this.subject).subscribe(allqnos=>{this.allqnos=allqnos; console.log(this.allqnos.length)});

    this.decreaseTime();
  
    setInterval(()=>{
    this.remainingTime=this.remainingTime-1;
    let minute=Math.floor(this.remainingTime/60);
    let second =this.remainingTime %60;
    this.durationMessage="Time remaining"+minute+":"+second;
    if(this.remainingTime==0)
    {
      this.endexam();
    }
   },1000) 

  }
  nextQuestion()

  {
    clearInterval(this.x);
    this.decreaseTime();
    

    this.selected=false;
    this.questionService.getAllAnswer().subscribe(answerarray=>this.allAnswers=answerarray);
    this.questionService.nextQuestion().subscribe(question=>this.question=question);

}
  decreaseTime() {
    this.maxtime=10;

    this.x=setInterval(()=>{
      
      this.maxtime--;

      console.log(this.maxtime);

      if(this.maxtime==0)
        this.nextQuestion();

    },1000);
  }

  getQuestion(eventobject:any)
  {
      let questionNumber=eventobject.target.value;
      console.log("selected question number is " + questionNumber);

      this.questionService.getQuestion(questionNumber).subscribe(question=>this.question=question);
  }




  previousQuestion()
  { 
    
    this.decreaseTime();
    this.selected=false;

    this.questionService.getAllAnswer().subscribe(answerarray=>this.allAnswers=answerarray);
    
    this.questionService.previousQuestion().subscribe(question=>this.question=question);
  
  }

  getcolor(currentoption:string)
  {
    for(let index=0; index <this.allAnswers.length; index++)
    {
      let answer =this.allAnswers[index];

      if( answer.qno==this.question.qno && answer.submittedAnswer==currentoption)
      return "green";
    }
    return "red"; 
  }

  
  isChecked(currentoption:string)
  {
    for(let index=0; index < this.allAnswers.length; index++)
    {
      let answer =this.allAnswers[index];

      if( answer.qno==this.question.qno && answer.submittedAnswer==currentoption)
      return true;
    }
    return false; 
  }
  saveAnswer()
  {
    this.answer.submittedAnswer=this.submittedAnswer;
    this.answer.qno=this.question.qno;
    this.answer.correctAnswer=this.question.answer;
    this.answer.qtext=this.question.qtext;

    this.questionService.saveAnswer(this.answer).subscribe();

    console.log("answer sumitted successfully");
  }
  endexam()
  {

      this.router.navigateByUrl("score");
      
  }

}
 
  
