import { Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { QuestionComponent } from './question/question.component';
import { ScoreComponent } from './score/score.component';
import { AdminComponent } from './admin/admin.component';
import { CheakingComponent } from './cheaking/cheaking.component';
import { ResultComponent } from './result/result.component';
import { ResultdisplayComponent } from './resultdisplay/resultdisplay.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';

export const routes: Routes = [

    {path:'register',component:RegisterComponent},  

    {path:'login',component:LoginComponent},

    {path:'welcome',component:WelcomeComponent},
    
    {path:'question',component:QuestionComponent},
 
    {path:'score',component:ScoreComponent},

    {path:'admin',component:AdminComponent},
    
    {path:'checking',component:CheakingComponent},

    {path:'result',component:ResultComponent},

    
    {path:'resultdisplay',component:ResultdisplayComponent},

    
    {path:'admindashboard',component:AdmindashboardComponent},

    



];
